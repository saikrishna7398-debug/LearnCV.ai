
import io
import os
import cv2
import time
import base64
import numpy as np
import streamlit as st
from PIL import Image, ImageOps, ImageCms

# ==============================
# Helpers
# ==============================

def load_image_file(uploaded_file):
    """Read an uploaded file into OpenCV BGR image and PIL image, plus metadata."""
    file_bytes = uploaded_file.read()
    np_arr = np.frombuffer(file_bytes, np.uint8)
    img_bgr = cv2.imdecode(np_arr, cv2.IMREAD_UNCHANGED)
    # Ensure we have 3 channels for most ops (drop alpha if present, keep a copy)
    alpha = None
    if img_bgr is None:
        return None, None, None, None, None
    if img_bgr.ndim == 2:
        img_bgr = cv2.cvtColor(img_bgr, cv2.COLOR_GRAY2BGR)
    if img_bgr.shape[2] == 4:
        alpha = img_bgr[:, :, 3]
        img_bgr = img_bgr[:, :, :3]

    pil_img = Image.open(io.BytesIO(file_bytes))
    dpi = pil_img.info.get("dpi", (None, None))
    fmt = pil_img.format
    return img_bgr, alpha, pil_img, dpi, fmt

def pil_to_bgr(pil_img):
    return cv2.cvtColor(np.array(pil_img.convert("RGB")), cv2.COLOR_RGB2BGR)

def bgr_to_rgb(img_bgr):
    return cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)

def ensure_gray(img_bgr):
    return cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)

def add_alpha(img_bgr, alpha):
    if alpha is None:
        return img_bgr
    return np.dstack([img_bgr, alpha])

def encode_image(img_bgr, fmt="PNG", quality=95, png_compress=3):
    """Return encoded image bytes and size for selected format and params."""
    ext = ".png"
    params = []
    if fmt.upper() == "JPG" or fmt.upper() == "JPEG":
        ext = ".jpg"
        params = [cv2.IMWRITE_JPEG_QUALITY, int(quality)]
    elif fmt.upper() == "BMP":
        ext = ".bmp"
    elif fmt.upper() == "PNG":
        ext = ".png"
        params = [cv2.IMWRITE_PNG_COMPRESSION, int(png_compress)]
    success, buf = cv2.imencode(ext, img_bgr, params)
    if not success:
        return None, 0, ext
    b = buf.tobytes()
    return b, len(b), ext

def bytes_to_human(n):
    for unit in ["B","KB","MB","GB"]:
        if n < 1024.0:
            return f"{n:3.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} TB"

def make_split_view(left_rgb, right_rgb, split_ratio=0.5):
    """Return a split-view image (left part from left_rgb, right from right_rgb)."""
    h, w = left_rgb.shape[:2]
    sr = max(0.0, min(1.0, split_ratio))
    split = int(w * sr)
    out = left_rgb.copy()
    out[:, :split] = left_rgb[:, :split]
    out[:, split:] = right_rgb[:, split:]
    # Draw handle line
    cv2.line(out, (split, 0), (split, h), (255, 255, 255), 2)
    return out

def rotate_image(img, angle_deg, center=None, scale=1.0):
    (h, w) = img.shape[:2]
    if center is None:
        center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, angle_deg, scale)
    rotated = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    return rotated

def translate_image(img, tx, ty):
    M = np.float32([[1, 0, tx], [0, 1, ty]])
    (h, w) = img.shape[:2]
    return cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)

def scale_image(img, fx, fy):
    return cv2.resize(img, None, fx=fx, fy=fy, interpolation=cv2.INTER_LINEAR if (fx>1 or fy>1) else cv2.INTER_AREA)

def affine_transform(img, src_pts, dst_pts):
    M = cv2.getAffineTransform(np.float32(src_pts), np.float32(dst_pts))
    (h, w) = img.shape[:2]
    return cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)

def perspective_transform(img, src_pts, dst_pts):
    M = cv2.getPerspectiveTransform(np.float32(src_pts), np.float32(dst_pts))
    (h, w) = img.shape[:2]
    return cv2.warpPerspective(img, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)

def histogram_equalization(img_bgr):
    img_yuv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2YCrCb)
    y, cr, cb = cv2.split(img_yuv)
    y_eq = cv2.equalizeHist(y)
    img_eq = cv2.merge([y_eq, cr, cb])
    return cv2.cvtColor(img_eq, cv2.COLOR_YCrCb2BGR)

def contrast_stretch(img_bgr, low=2, high=98):
    # percentile stretching on luminance
    img = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(img)
    p_low = np.percentile(l, low)
    p_high = np.percentile(l, high)
    l_stretched = np.clip((l - p_low) * 255.0 / max(1, (p_high - p_low)), 0, 255).astype(np.uint8)
    out = cv2.merge([l_stretched, a, b])
    return cv2.cvtColor(out, cv2.COLOR_LAB2BGR)

def sharpen(img_bgr, amount=1.0):
    # Unsharp masking
    blur = cv2.GaussianBlur(img_bgr, (0, 0), sigmaX=2.0)
    return cv2.addWeighted(img_bgr, 1 + amount, blur, -amount, 0)

def sobel_edges(gray):
    gx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    mag = cv2.magnitude(gx, gy)
    mag = np.uint8(np.clip(mag / (mag.max() + 1e-5) * 255, 0, 255))
    return mag

def laplacian_edges(gray):
    lap = cv2.Laplacian(gray, cv2.CV_64F, ksize=3)
    lap = np.uint8(np.clip(np.abs(lap) / (np.max(np.abs(lap)) + 1e-5) * 255, 0, 255))
    return lap

def morphology(img_gray, op="dilate", k=3, iters=1):
    kernel = np.ones((k,k), np.uint8)
    if op == "dilate":
        return cv2.dilate(img_gray, kernel, iterations=iters)
    if op == "erode":
        return cv2.erode(img_gray, kernel, iterations=iters)
    if op == "open":
        return cv2.morphologyEx(img_gray, cv2.MORPH_OPEN, kernel, iterations=iters)
    if op == "close":
        return cv2.morphologyEx(img_gray, cv2.MORPH_CLOSE, kernel, iterations=iters)
    return img_gray

def ycbcr_convert(img_bgr):
    return cv2.cvtColor(img_bgr, cv2.COLOR_BGR2YCrCb)

def rgb_bgr_swap(img_bgr):
    # BGR -> RGB and back
    return cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)

def compute_info(img_bgr, fmt, dpi, raw_bytes=None):
    h, w = img_bgr.shape[:2]
    c = img_bgr.shape[2] if img_bgr.ndim == 3 else 1
    size_bytes = len(raw_bytes) if raw_bytes is not None else None
    return {
        "Dimensions (HxW)": f"{h} x {w}",
        "Channels": c,
        "Estimated DPI (if present)": dpi if dpi and any(dpi) else "N/A",
        "Format (source)": fmt or "Unknown",
        "Approx. File Size": bytes_to_human(size_bytes) if size_bytes is not None else "N/A",
    }

# ==============================
# Streamlit UI
# ==============================

st.set_page_config(page_title="Image Processing Toolkit (OpenCV + Streamlit)", layout="wide")

st.title("🖼️ Image Processing Toolkit — OpenCV + Streamlit")
st.caption("Upload an image, apply classic vision operations, and compare results side-by-side.")

# --- Menu bar emulation
with st.container():
    col1, col2, col3, col4 = st.columns([3,1,1,1])
    with col1:
        uploaded_file = st.file_uploader("📂 Open image file", type=["png","jpg","jpeg","bmp","tiff"], accept_multiple_files=False, label_visibility="visible")
    with col2:
        save_clicked = st.button("💾 Save")
    with col3:
        clear_clicked = st.button("🧹 Clear")
    with col4:
        exit_clicked = st.button("⏻ Exit")

if exit_clicked:
    st.stop()

# State
if "orig_bgr" not in st.session_state:
    st.session_state.orig_bgr = None
if "alpha" not in st.session_state:
    st.session_state.alpha = None
if "pil" not in st.session_state:
    st.session_state.pil = None
if "dpi" not in st.session_state:
    st.session_state.dpi = (None, None)
if "fmt" not in st.session_state:
    st.session_state.fmt = None
if "raw_bytes" not in st.session_state:
    st.session_state.raw_bytes = None
if "processed_bgr" not in st.session_state:
    st.session_state.processed_bgr = None

if uploaded_file is not None:
    st.session_state.raw_bytes = uploaded_file.getvalue()
    img_bgr, alpha, pil_img, dpi, fmt = load_image_file(uploaded_file)
    if img_bgr is None:
        st.error("Failed to load image. Please try a different file.")
    else:
        st.session_state.orig_bgr = img_bgr
        st.session_state.alpha = alpha
        st.session_state.pil = pil_img
        st.session_state.dpi = dpi
        st.session_state.fmt = fmt
        st.session_state.processed_bgr = img_bgr.copy()

if clear_clicked:
    for k in ["orig_bgr","alpha","pil","dpi","fmt","raw_bytes","processed_bgr"]:
        st.session_state[k] = None
    st.experimental_rerun()

# Sidebar — Operations
st.sidebar.header("🔧 Operations")
mode = st.sidebar.radio(
    "Category",
    ["Image Info", "Color Conversions", "Transformations", "Bitwise Ops", "Filtering & Morphology", "Enhancement", "Edge Detection", "Compression"],
)

if st.session_state.orig_bgr is None:
    st.info("Upload an image to get started.")
    st.stop()

orig_bgr = st.session_state.orig_bgr.copy()
proc_bgr = st.session_state.processed_bgr.copy() if st.session_state.processed_bgr is not None else orig_bgr.copy()

# ----------- Category Panels -----------

if mode == "Image Info":
    st.sidebar.subheader("📐 Properties")
    show_channels = st.sidebar.checkbox("Show channels separately", value=False)
    info = compute_info(orig_bgr, st.session_state.fmt, st.session_state.dpi, st.session_state.raw_bytes)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("**Original**")
        st.image(bgr_to_rgb(orig_bgr), use_column_width=True)
    with c2:
        st.markdown("**Processed** (same as original)")
        st.image(bgr_to_rgb(proc_bgr), use_column_width=True)

    if show_channels:
        r, g, b = cv2.split(bgr_to_rgb(orig_bgr))
        st.markdown("**Channels (R, G, B)**")
        cc1, cc2, cc3 = st.columns(3)
        with cc1: st.image(r, caption="Red", use_column_width=True, clamp=True)
        with cc2: st.image(g, caption="Green", use_column_width=True, clamp=True)
        with cc3: st.image(b, caption="Blue", use_column_width=True, clamp=True)

    st.divider()
    st.subheader("ℹ️ Status Bar")
    st.json(info)

elif mode == "Color Conversions":
    choice = st.sidebar.selectbox("Conversion", ["RGB ↔ BGR", "RGB ↔ HSV", "RGB ↔ YCbCr", "RGB ↔ Grayscale"])
    if choice == "RGB ↔ BGR":
        proc_bgr = cv2.cvtColor(cv2.cvtColor(orig_bgr, cv2.COLOR_BGR2RGB), cv2.COLOR_RGB2BGR)
    elif choice == "RGB ↔ HSV":
        hsv = cv2.cvtColor(orig_bgr, cv2.COLOR_BGR2HSV)
        proc_bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    elif choice == "RGB ↔ YCbCr":
        ycc = cv2.cvtColor(orig_bgr, cv2.COLOR_BGR2YCrCb)
        proc_bgr = cv2.cvtColor(ycc, cv2.COLOR_YCrCb2BGR)
    elif choice == "RGB ↔ Grayscale":
        gray = ensure_gray(orig_bgr)
        proc_bgr = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)

elif mode == "Transformations":
    tchoice = st.sidebar.selectbox("Transform", ["Rotation", "Scaling", "Translation", "Affine Transform", "Perspective Transform"])

    if tchoice == "Rotation":
        angle = st.sidebar.slider("Angle (degrees)", -180.0, 180.0, 15.0, 1.0)
        scale = st.sidebar.slider("Scale", 0.1, 3.0, 1.0, 0.1)
        proc_bgr = rotate_image(orig_bgr, angle, scale=scale)

    elif tchoice == "Scaling":
        fx = st.sidebar.slider("fx (X scale)", 0.1, 3.0, 1.5, 0.1)
        fy = st.sidebar.slider("fy (Y scale)", 0.1, 3.0, 1.5, 0.1)
        proc_bgr = scale_image(orig_bgr, fx, fy)

    elif tchoice == "Translation":
        max_shift_x = int(orig_bgr.shape[1] * 0.5)
        max_shift_y = int(orig_bgr.shape[0] * 0.5)
        tx = st.sidebar.slider("Shift X (pixels)", -max_shift_x, max_shift_x, 50, 1)
        ty = st.sidebar.slider("Shift Y (pixels)", -max_shift_y, max_shift_y, 50, 1)
        proc_bgr = translate_image(orig_bgr, tx, ty)

    elif tchoice == "Affine Transform":
        h, w = orig_bgr.shape[:2]
        src = np.float32([[0,0], [w-1,0], [0,h-1]])
        dst = np.float32([
            [0 + st.sidebar.slider("dst0.x", 0, w-1, 0, 1), 0 + st.sidebar.slider("dst0.y", 0, h-1, 0, 1)],
            [w-1 - st.sidebar.slider("dst1.x", 0, w-1, 0, 1), 0 + st.sidebar.slider("dst1.y", 0, h-1, 0, 1)],
            [0 + st.sidebar.slider("dst2.x", 0, w-1, 0, 1), h-1 - st.sidebar.slider("dst2.y", 0, h-1, 0, 1)],
        ])
        proc_bgr = affine_transform(orig_bgr, src, dst)

    elif tchoice == "Perspective Transform":
        h, w = orig_bgr.shape[:2]
        src = np.float32([[0,0],[w-1,0],[w-1,h-1],[0,h-1]])
        dst = np.float32([
            [st.sidebar.slider("dst0.x", 0, w-1, 0, 1), st.sidebar.slider("dst0.y", 0, h-1, 0, 1)],
            [st.sidebar.slider("dst1.x", 0, w-1, w-1, 1), st.sidebar.slider("dst1.y", 0, h-1, 0, 1)],
            [st.sidebar.slider("dst2.x", 0, w-1, w-1, 1), st.sidebar.slider("dst2.y", 0, h-1, h-1, 1)],
            [st.sidebar.slider("dst3.x", 0, w-1, 0, 1), st.sidebar.slider("dst3.y", 0, h-1, h-1, 1)],
        ])
        proc_bgr = perspective_transform(orig_bgr, src, dst)

elif mode == "Bitwise Ops":
    st.sidebar.info("Bitwise ops run against a thresholded mask of the original.")
    gray = ensure_gray(orig_bgr)
    thresh_val = st.sidebar.slider("Threshold", 0, 255, 128, 1)
    _, mask = cv2.threshold(gray, thresh_val, 255, cv2.THRESH_BINARY)
    op = st.sidebar.selectbox("Operation", ["AND", "OR", "XOR", "NOT"])
    if op == "AND":
        proc_bgr = cv2.bitwise_and(orig_bgr, orig_bgr, mask=mask)
    elif op == "OR":
        proc_bgr = cv2.bitwise_or(orig_bgr, orig_bgr, mask=mask)
    elif op == "XOR":
        proc_bgr = cv2.bitwise_xor(orig_bgr, orig_bgr, mask=mask)
    elif op == "NOT":
        proc_bgr = cv2.bitwise_not(orig_bgr, mask=mask)

elif mode == "Filtering & Morphology":
    subgroup = st.sidebar.selectbox("Subgroup", ["Smoothing", "Sobel/Laplacian", "Morphology"])

    if subgroup == "Smoothing":
        ftype = st.sidebar.selectbox("Filter", ["Gaussian", "Median", "Mean (Box)"])
        k = st.sidebar.slider("Kernel size (odd)", 1, 31, 5, 2)
        if ftype == "Gaussian":
            proc_bgr = cv2.GaussianBlur(orig_bgr, (k, k), 0)
        elif ftype == "Median":
            proc_bgr = cv2.medianBlur(orig_bgr, k)
        elif ftype == "Mean (Box)":
            proc_bgr = cv2.blur(orig_bgr, (k, k))

    elif subgroup == "Sobel/Laplacian":
        gray = ensure_gray(orig_bgr)
        which = st.sidebar.selectbox("Edge Filter", ["Sobel", "Laplacian"])
        if which == "Sobel":
            edges = sobel_edges(gray)
        else:
            edges = laplacian_edges(gray)
        proc_bgr = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

    elif subgroup == "Morphology":
        gray = ensure_gray(orig_bgr)
        op = st.sidebar.selectbox("Operation", ["Dilation", "Erosion", "Opening", "Closing"])
        k = st.sidebar.slider("Kernel size", 1, 31, 5, 2)
        iters = st.sidebar.slider("Iterations", 1, 10, 1, 1)
        op_map = {"Dilation":"dilate","Erosion":"erode","Opening":"open","Closing":"close"}
        m = morphology(gray, op_map[op], k, iters)
        proc_bgr = cv2.cvtColor(m, cv2.COLOR_GRAY2BGR)

elif mode == "Enhancement":
    ench = st.sidebar.selectbox("Enhancement", ["Histogram Equalization", "Contrast Stretching", "Sharpening"])
    if ench == "Histogram Equalization":
        proc_bgr = histogram_equalization(orig_bgr)
    elif ench == "Contrast Stretching":
        low = st.sidebar.slider("Low percentile", 0, 20, 2, 1)
        high = st.sidebar.slider("High percentile", 80, 100, 98, 1)
        if low >= high:
            st.sidebar.warning("Low must be < High. Adjust sliders.")
        proc_bgr = contrast_stretch(orig_bgr, low, high)
    elif ench == "Sharpening":
        amt = st.sidebar.slider("Amount", 0.0, 3.0, 1.0, 0.1)
        proc_bgr = sharpen(orig_bgr, amt)

elif mode == "Edge Detection":
    e = st.sidebar.selectbox("Detector", ["Sobel", "Canny", "Laplacian"])
    gray = ensure_gray(orig_bgr)
    if e == "Sobel":
        edges = sobel_edges(gray)
    elif e == "Laplacian":
        edges = laplacian_edges(gray)
    else:  # Canny
        t1 = st.sidebar.slider("Canny Threshold 1", 0, 255, 50, 1)
        t2 = st.sidebar.slider("Canny Threshold 2", 0, 255, 150, 1)
        edges = cv2.Canny(gray, t1, t2)
    proc_bgr = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

elif mode == "Compression":
    fmt = st.sidebar.selectbox("Save Format", ["JPG", "PNG", "BMP"])
    if fmt == "JPG":
        q = st.sidebar.slider("JPEG Quality", 1, 100, 90, 1)
        bytes_out, size_out, ext = encode_image(orig_bgr, fmt="JPG", quality=q)
    elif fmt == "PNG":
        c = st.sidebar.slider("PNG Compression (0-9)", 0, 9, 3, 1)
        bytes_out, size_out, ext = encode_image(orig_bgr, fmt="PNG", png_compress=c)
    else:
        bytes_out, size_out, ext = encode_image(orig_bgr, fmt="BMP")

    # Show comparison sizes
    st.info(f"Encoded as {fmt} → {bytes_to_human(size_out)}")

    if bytes_out is not None:
        st.download_button(
            "⬇️ Download Encoded Image",
            data=bytes_out,
            file_name=f"processed{ext}",
            mime=f"image/{fmt.lower()}"
        )
    # Keep proc_bgr same as original for visual parity
    proc_bgr = orig_bgr.copy()

# --- Update processed in session
st.session_state.processed_bgr = proc_bgr

# --- Split view toggle and sliders
st.sidebar.markdown("---")
split_mode = st.sidebar.checkbox("🪟 Comparison Split (drag ratio)", value=False)
split_ratio = st.sidebar.slider("Split ratio (left→right)", 0.0, 1.0, 0.5, 0.01) if split_mode else 0.5

# --- Display Area
left_col, right_col = st.columns(2, gap="large")
with left_col:
    st.subheader("Original")
    st.image(bgr_to_rgb(orig_bgr), use_column_width=True)
with right_col:
    st.subheader("Processed")
    if split_mode:
        split_img = make_split_view(bgr_to_rgb(orig_bgr), bgr_to_rgb(proc_bgr), split_ratio=split_ratio)
        st.image(split_img, use_column_width=True)
    else:
        st.image(bgr_to_rgb(proc_bgr), use_column_width=True)

# --- Save processed image button
if save_clicked and st.session_state.processed_bgr is not None:
    # Default to PNG
    out_bytes, out_size, ext = encode_image(st.session_state.processed_bgr, fmt="PNG", png_compress=3)
    if out_bytes:
        st.success(f"Prepared download ({bytes_to_human(out_size)}). Use the button below to save.")
        st.download_button("💾 Download Processed (PNG)", data=out_bytes, file_name="processed.png", mime="image/png")
    else:
        st.error("Could not encode image for saving.")

# --- Status Bar (Bottom)
st.divider()
st.subheader("📊 Status Bar")
status_info = compute_info(orig_bgr, st.session_state.fmt, st.session_state.dpi, st.session_state.raw_bytes)
try:
    enc = encode_image(proc_bgr, fmt="PNG")[0]
    status_info["Processed Size (PNG approx)"] = bytes_to_human(len(enc)) if enc is not None else "N/A"
except Exception:
    status_info["Processed Size (PNG approx)"] = "N/A"
st.json(status_info)

st.caption("Tip: Use the sidebar to switch categories and tune parameters.")
